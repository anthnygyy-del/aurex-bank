const $ = (id) => document.getElementById(id);
let state = null;
const pageNames = {dashboard:"Overview",accounts:"My accounts",transfers:"Transfers",payments:"Bill payments",transactions:"Transactions",cards:"Cards",settings:"Settings"};
const fmt = cents => new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(cents/100);
const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const accountName = kind => kind === "checking" ? "AUREX Everyday Checking" : "AUREX Growth Savings";
const dateFmt = value => { const d = new Date(value.includes("T") ? value : value.replace(" ","T")+"Z"); return isNaN(d) ? value : d.toLocaleString([], {month:"short",day:"numeric",year:"numeric",hour:"numeric",minute:"2-digit"}); };
function toast(message,error=false){const el=$("toast");el.textContent=message;el.className="toast show"+(error?" error":"");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.className="toast",3500)}
async function api(url, options={}) {
  const response = await fetch(url,{credentials:"same-origin",headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  const data = await response.json().catch(()=>({error:"Unexpected server response."}));
  if(!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function account(kind){return state?.accounts.find(a=>a.kind===kind)}
function total(){return state.accounts.reduce((sum,a)=>sum+a.balanceCents,0)}
function initDate(){ $("today").textContent = new Date().toLocaleDateString([], {weekday:"short",month:"short",day:"numeric",year:"numeric"}); const hour=new Date().getHours();$("greeting").textContent=(hour<12?"Good morning":hour<18?"Good afternoon":"Good evening")+", "+state.user.name.split(" ")[0];}
function renderAccounts(){
 const html=state.accounts.map(a=>`<div class="account-row"><div class="account-icon">${a.kind==="checking"?"▤":"◈"}</div><div class="account-meta"><strong>${esc(a.name)}</strong><small>${esc(a.accountNumber)} · ${a.kind==="checking"?"Checking":"Savings"}</small></div><div class="account-balance">${fmt(a.balanceCents)}</div></div>`).join("");
 $("accountSummary").innerHTML=html; $("accountsList").innerHTML=html;
 $("totalBalance").textContent=fmt(total());$("checkingBalance").textContent=fmt(account("checking").balanceCents);$("savingsBalance").textContent=fmt(account("savings").balanceCents);
 $("transferAvailable").textContent=fmt(account($("fromAccount").value).balanceCents); $("externalAvailable").textContent=fmt(account("checking").balanceCents);
}
function txIcon(t){return t.type==="Deposit"?"＋":t.type==="Withdrawal"?"−":t.type==="Transfer"?"⇄":t.type==="Bill payment"?"▣":"↕"}
function renderRecent(){
 const tx=state.transactions.slice(0,5);
 $("recentTx").innerHTML=tx.length?tx.map(t=>`<div class="tx"><div class="tx-icon">${txIcon(t)}</div><div class="tx-info"><strong>${esc(t.description)}</strong><span>${esc(dateFmt(t.createdAt))} · ${esc(t.accountKind)}</span></div><div class="tx-amount ${t.amountCents>0?"positive":""}">${t.amountCents>0?"+":"−"}${fmt(Math.abs(t.amountCents))}<small>${esc(t.status)}</small></div></div>`).join(""):`<div class="empty">No transactions yet.</div>`;
}
function renderTransactions(){
 const query=$("txSearch").value.trim().toLowerCase();
 const tx=state.transactions.filter(t=>[t.description,t.type,t.accountName,t.reference,t.accountKind].join(" ").toLowerCase().includes(query));
 $("txCount").textContent=`${tx.length} transaction${tx.length===1?"":"s"}`;
 $("txTable").innerHTML=tx.length?tx.map(t=>`<tr><td><strong>${esc(t.description)}</strong><span class="sub">${esc(t.reference)}</span></td><td>${esc(dateFmt(t.createdAt))}</td><td>${esc(t.accountName)}</td><td><span class="status">${esc(t.status)}</span></td><td class="${t.amountCents>0?"amount-positive":"amount-negative"}">${t.amountCents>0?"+":"−"}${fmt(Math.abs(t.amountCents))}</td></tr>`).join(""):`<tr><td colspan="5" class="empty">No matching transactions.</td></tr>`;
}
function render(){
 $("userName").textContent=state.user.name;$("avatar").textContent=state.user.name.split(/\s+/).map(s=>s[0]).slice(0,2).join("").toUpperCase();
 $("settingsName").textContent=state.user.name;$("settingsEmail").textContent=state.user.email;
 $("cardStatus").textContent=state.user.cardFrozen?"Frozen in simulator":"Active in simulator";
 $("freezeBtn").textContent=state.user.cardFrozen?"Unfreeze simulated card":"Freeze simulated card";
 renderAccounts();renderRecent();renderTransactions();initDate();
}
function showPage(name){
 if(!pageNames[name])name="dashboard";
 document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+name));
 document.querySelectorAll(".nav-btn[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
 $("pageCrumb").textContent=pageNames[name];$("sidebar").classList.remove("open");
 if(name==="transactions")renderTransactions();
}
async function refresh(){state=await api("/api/me");$("loginScreen").classList.add("hidden");$("appScreen").classList.remove("hidden");render();}
$("loginForm").addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/login",{method:"POST",body:JSON.stringify({email:$("loginEmail").value,password:$("loginPassword").value})});await refresh();toast("Signed in to the AUREX simulator.");}catch(err){toast(err.message,true)}});
$("logoutBtn").addEventListener("click",async()=>{try{await api("/api/logout",{method:"POST"});state=null;$("appScreen").classList.add("hidden");$("loginScreen").classList.remove("hidden");toast("You have signed out.");}catch(e){toast(e.message,true)}});
document.addEventListener("click",async e=>{
 const nav=e.target.closest("[data-page]");if(nav){showPage(nav.dataset.page);return}
 const go=e.target.closest("[data-goto]");if(go){showPage(go.dataset.goto);return}
});
$("menuBtn").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
$("fromAccount").addEventListener("change",()=>{if(state)$("transferAvailable").textContent=fmt(account($("fromAccount").value).balanceCents);if($("fromAccount").value===$("toAccount").value)$("toAccount").value=$("fromAccount").value==="checking"?"savings":"checking"});
$("toAccount").addEventListener("change",()=>{if($("toAccount").value===$("fromAccount").value)$("fromAccount").value=$("toAccount").value==="checking"?"savings":"checking";if(state)$("transferAvailable").textContent=fmt(account($("fromAccount").value).balanceCents)});
function showTransferReceipt(r){
 const amount=fmt(r.amountCents);
 $("receiptContent").innerHTML=`<div class="receipt-brand"><div class="receipt-mark">A</div><div><strong>AUREX</strong><span>TRANSFER RECEIPT · SIMULATION</span></div></div>
 <div class="receipt-result"><div class="receipt-check">✓</div><h2>Transfer recorded</h2><p>${esc(amount)} USD</p><span>${esc(r.status)}</span></div>
 <div class="receipt-details"><div><span>From</span><strong>${esc(r.sender)}</strong><small>${esc(r.fromAccount)}</small></div>
 <div><span>Recipient</span><strong>${esc(r.recipient)}</strong><small>${esc(r.bank)}</small></div>
 <div><span>Recipient account</span><strong>${esc(r.accountNumber)}</strong></div>
 <div><span>Date</span><strong>${esc(dateFmt(r.createdAt))}</strong></div>
 ${r.note?`<div><span>Payment note</span><strong>${esc(r.note)}</strong></div>`:""}
 <div><span>Reference</span><strong class="receipt-ref">${esc(r.reference)}</strong></div></div>
 <p class="receipt-foot">Recorded in the AUREX simulator only. No real bank was contacted and no real funds moved.</p>`;
 $("receiptDialog").showModal();
}
$("receiptClose").addEventListener("click",()=>$("receiptDialog").close());
$("receiptPrint").addEventListener("click",()=>window.print());
$("externalTransferForm").addEventListener("submit",async e=>{
 e.preventDefault();
 try{
  const data=await api("/api/transfer/external-simulated",{method:"POST",body:JSON.stringify({recipient:$("externalRecipient").value,bank:$("externalBank").value,accountNumber:$("externalAccountNumber").value,amount:$("externalAmount").value,note:$("externalNote").value})});
  state=data;render();const receipt=data.receipt;e.target.reset();renderAccounts();showTransferReceipt(receipt);toast("Simulated transfer recorded.");
 }catch(err){toast(err.message,true)}
});

$("accountForm").addEventListener("submit",async e=>{e.preventDefault();try{state=await api("/api/transaction",{method:"POST",body:JSON.stringify({action:$("accountAction").value,account:$("accountSelect").value,amount:$("accountAmount").value,description:$("accountMemo").value})});render();e.target.reset();toast("Simulated account activity completed.");}catch(err){toast(err.message,true)}});
$("transferForm").addEventListener("submit",async e=>{e.preventDefault();if($("fromAccount").value===$("toAccount").value)return toast("Choose two different accounts.",true);try{state=await api("/api/transfer",{method:"POST",body:JSON.stringify({from:$("fromAccount").value,to:$("toAccount").value,amount:$("transferAmount").value,note:$("transferNote").value})});render();e.target.reset();$("fromAccount").value="checking";$("toAccount").value="savings";renderAccounts();toast("Simulated transfer completed.");}catch(err){toast(err.message,true)}});
$("paymentForm").addEventListener("submit",async e=>{e.preventDefault();try{state=await api("/api/payment",{method:"POST",body:JSON.stringify({biller:$("biller").value,amount:$("paymentAmount").value,reference:$("paymentReference").value})});render();e.target.reset();toast("Fictional bill payment completed.");}catch(err){toast(err.message,true)}});
$("freezeBtn").addEventListener("click",async()=>{try{state=await api("/api/card",{method:"POST",body:JSON.stringify({frozen:!state.user.cardFrozen})});render();toast(state.user.cardFrozen?"Simulated card frozen.":"Simulated card unfrozen.");}catch(e){toast(e.message,true)}});
$("txSearch").addEventListener("input",()=>state&&renderTransactions());
function exportCsv(){window.location.href="/api/export.csv"}
$("exportBtn").addEventListener("click",exportCsv);$("settingsExport").addEventListener("click",exportCsv);
$("helpBtn").addEventListener("click",()=>toast("AUREX is a fictional banking simulator. Use the navigation to test simulated account actions."));
(async()=>{try{await refresh()}catch(e){$("loginScreen").classList.remove("hidden")}})();
