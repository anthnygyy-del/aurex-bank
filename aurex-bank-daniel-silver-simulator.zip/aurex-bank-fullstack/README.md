# AUREX Bank — Full-Stack Banking Simulator

AUREX is a fictional American-style banking simulator. It uses fictional accounts and simulated money only. It is not a real bank, does not connect to financial institutions, and cannot move real funds.

## Requirements
- Node.js 20 or newer
- npm

## Run locally
1. Extract this folder.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

The server creates `aurex.sqlite` automatically and seeds a sample account on first run.

## Sample sign-in
- Email: `demo@aurex.test`
- Password: `Simulator123!`

Change the sample password and configure a strong session secret before using this project beyond local testing. This starter is for local development, not production banking.

## Included
- Server-side session login and logout
- Password hashing with bcrypt
- SQLite database for users, accounts, and transaction records
- $950,000 starting simulated balance ($850,000 checking + $100,000 savings)
- Transfers between the user's own simulated accounts
- Interactive external-recipient transfer simulation with printable receipt (no bank connection or real funds movement)
- Simulated deposits and withdrawals
- Fictional bill payments
- Transaction history and CSV export
- Simulated virtual-card freeze toggle
- Server-side validation and transaction database transactions

## Safety notes
- All balances are fictional.
- No real payment processing, bank APIs, external transfers, or real card credentials are implemented.
- The sample account is seeded for convenience. Remove or change it before sharing the project.
- For any public deployment, use HTTPS, a strong secret stored in environment variables, secure cookie settings, CSRF protection, rate limiting, and a security review.
