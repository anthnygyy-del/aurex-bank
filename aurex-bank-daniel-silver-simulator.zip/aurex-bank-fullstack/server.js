const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, "aurex.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  card_frozen INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK(kind IN ('checking','savings')),
  name TEXT NOT NULL,
  account_number TEXT NOT NULL,
  balance_cents INTEGER NOT NULL DEFAULT 0 CHECK(balance_cents >= 0),
  UNIQUE(user_id, kind)
);
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id INTEGER NOT NULL REFERENCES accounts(id),
  type TEXT NOT NULL,
  description TEXT NOT NULL,
  amount_cents INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'Completed',
  reference TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

function cents(value) {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0 || n > 100000000) throw new Error("Enter a valid amount greater than zero.");
  return Math.round(n * 100);
}
function reference() { return "AX-" + crypto.randomBytes(5).toString("hex").toUpperCase(); }
function money(c) { return (c / 100).toFixed(2); }

const userCount = db.prepare("SELECT COUNT(*) AS n FROM users").get().n;
// Keep the bundled demo profile name consistent for existing local databases.
db.prepare("UPDATE users SET name=? WHERE email=? AND name=?").run("Daniel Silver", "demo@aurex.test", "Jordan Davis");
if (!userCount) {
  const hash = bcrypt.hashSync("Simulator123!", 12);
  const result = db.prepare("INSERT INTO users (name,email,password_hash) VALUES (?,?,?)")
    .run("Daniel Silver", "demo@aurex.test", hash);
  const uid = result.lastInsertRowid;
  const insertAccount = db.prepare("INSERT INTO accounts (user_id,kind,name,account_number,balance_cents) VALUES (?,?,?,?,?)");
  const checkingId = insertAccount.run(uid, "checking", "AUREX Everyday Checking", "•••• 1048", 85000000).lastInsertRowid;
  const savingsId = insertAccount.run(uid, "savings", "AUREX Growth Savings", "•••• 2096", 10000000).lastInsertRowid;
  const insertTx = db.prepare("INSERT INTO transactions (user_id,account_id,type,description,amount_cents,reference) VALUES (?,?,?,?,?,?)");
  insertTx.run(uid, checkingId, "Deposit", "Initial simulated balance", 85000000, reference());
  insertTx.run(uid, savingsId, "Deposit", "Initial simulated balance", 10000000, reference());
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  name: "aurex.sid",
  secret: process.env.SESSION_SECRET || "local-dev-only-change-this-session-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000 * 60 * 60 * 4 }
}));
app.use(express.static(path.join(__dirname, "public")));

function auth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please sign in to continue." });
  next();
}
function getAccounts(userId) {
  return db.prepare("SELECT id,kind,name,account_number AS accountNumber,balance_cents AS balanceCents FROM accounts WHERE user_id=? ORDER BY id").all(userId);
}
function addTx(userId, accountId, type, description, amountCents) {
  db.prepare("INSERT INTO transactions (user_id,account_id,type,description,amount_cents,reference) VALUES (?,?,?,?,?,?)")
    .run(userId, accountId, type, description.slice(0, 100), amountCents, reference());
}
function snapshot(userId) {
  const user = db.prepare("SELECT id,name,email,card_frozen AS cardFrozen FROM users WHERE id=?").get(userId);
  const accounts = getAccounts(userId);
  const transactions = db.prepare(`
    SELECT t.id,t.type,t.description,t.amount_cents AS amountCents,t.status,t.reference,t.created_at AS createdAt,
           a.kind AS accountKind,a.name AS accountName
    FROM transactions t JOIN accounts a ON a.id=t.account_id
    WHERE t.user_id=? ORDER BY t.id DESC LIMIT 100
  `).all(userId);
  return { user, accounts, transactions, simulator: true };
}

app.post("/api/login", (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT id,name,email,password_hash FROM users WHERE email=?").get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: "Email or password is incorrect." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start a session." });
    req.session.userId = user.id;
    res.json({ ok: true });
  });
});
app.post("/api/logout", (req, res) => req.session.destroy(() => {
  res.clearCookie("aurex.sid");
  res.json({ ok: true });
}));
app.get("/api/me", auth, (req, res) => res.json(snapshot(req.session.userId)));
app.post("/api/transaction", auth, (req, res) => {
  const userId = req.session.userId;
  const action = String(req.body.action || "");
  const description = String(req.body.description || "").trim().slice(0, 100);
  let amount;
  try { amount = cents(req.body.amount); } catch (e) { return res.status(400).json({ error: e.message }); }
  const accounts = getAccounts(userId);
  const kind = String(req.body.account || "checking");
  const account = accounts.find(a => a.kind === kind);
  if (!account) return res.status(400).json({ error: "Choose a valid account." });
  const run = db.transaction(() => {
    const current = db.prepare("SELECT balance_cents FROM accounts WHERE id=? AND user_id=?").get(account.id, userId);
    if (action === "deposit") {
      db.prepare("UPDATE accounts SET balance_cents=balance_cents+? WHERE id=?").run(amount, account.id);
      addTx(userId, account.id, "Deposit", description || "Simulated cash deposit", amount);
    } else if (action === "withdraw") {
      if (current.balance_cents < amount) throw new Error("Insufficient simulated funds.");
      db.prepare("UPDATE accounts SET balance_cents=balance_cents-? WHERE id=?").run(amount, account.id);
      addTx(userId, account.id, "Withdrawal", description || "Simulated withdrawal", -amount);
    } else {
      throw new Error("Unsupported transaction.");
    }
  });
  try { run(); res.json(snapshot(userId)); } catch (e) { res.status(400).json({ error: e.message || "Transaction failed." }); }
});
app.post("/api/transfer", auth, (req, res) => {
  const userId = req.session.userId;
  const fromKind = String(req.body.from || "");
  const toKind = String(req.body.to || "");
  const note = String(req.body.note || "").trim().slice(0, 80);
  if (!["checking","savings"].includes(fromKind) || !["checking","savings"].includes(toKind) || fromKind === toKind)
    return res.status(400).json({ error: "Choose two different AUREX accounts." });
  let amount;
  try { amount = cents(req.body.amount); } catch (e) { return res.status(400).json({ error: e.message }); }
  const accounts = getAccounts(userId);
  const from = accounts.find(a => a.kind === fromKind), to = accounts.find(a => a.kind === toKind);
  try {
    db.transaction(() => {
      const current = db.prepare("SELECT balance_cents FROM accounts WHERE id=?").get(from.id);
      if (current.balance_cents < amount) throw new Error("Insufficient simulated funds.");
      db.prepare("UPDATE accounts SET balance_cents=balance_cents-? WHERE id=?").run(amount, from.id);
      db.prepare("UPDATE accounts SET balance_cents=balance_cents+? WHERE id=?").run(amount, to.id);
      addTx(userId, from.id, "Transfer", note || `Transfer to ${to.name}`, -amount);
      addTx(userId, to.id, "Transfer", note || `Transfer from ${from.name}`, amount);
    })();
    res.json(snapshot(userId));
  } catch (e) { res.status(400).json({ error: e.message || "Transfer failed." }); }
});
app.post("/api/transfer/external-simulated", auth, (req, res) => {
  const userId = req.session.userId;
  const recipient = String(req.body.recipient || "").trim().slice(0, 80);
  const bank = String(req.body.bank || "").trim().slice(0, 80);
  const accountNumber = String(req.body.accountNumber || "").replace(/\s+/g, "");
  const note = String(req.body.note || "").trim().slice(0, 80);
  if (recipient.length < 2 || bank.length < 2) return res.status(400).json({ error: "Enter a recipient name and bank name." });
  if (!/^\d{6,20}$/.test(accountNumber)) return res.status(400).json({ error: "Enter a fictional account number containing 6 to 20 digits." });
  let amount;
  try { amount = cents(req.body.amount); } catch (e) { return res.status(400).json({ error: e.message }); }
  const from = getAccounts(userId).find(a => a.kind === "checking");
  const ref = reference();
  try {
    db.transaction(() => {
      const current = db.prepare("SELECT balance_cents FROM accounts WHERE id=? AND user_id=?").get(from.id, userId);
      if (!current || current.balance_cents < amount) throw new Error("Insufficient simulated funds.");
      db.prepare("UPDATE accounts SET balance_cents=balance_cents-? WHERE id=? AND user_id=?").run(amount, from.id, userId);
      db.prepare("INSERT INTO transactions (user_id,account_id,type,description,amount_cents,status,reference) VALUES (?,?,?,?,?,?,?)")
        .run(userId, from.id, "External transfer (simulated)", `To ${recipient} · ${bank} · acct ending ${accountNumber.slice(-4)}`, -amount, "Simulated", ref);
    })();
    const createdAt = db.prepare("SELECT created_at AS createdAt FROM transactions WHERE reference=?").get(ref).createdAt;
    res.json({ ...snapshot(userId), receipt: {
      reference: ref, createdAt, amountCents: amount, sender: "Daniel Silver",
      fromAccount: from.name, recipient, bank, accountNumber: "••••" + accountNumber.slice(-4),
      note, status: "Simulated — no real funds moved"
    }});
  } catch (e) { res.status(400).json({ error: e.message || "Simulated transfer failed." }); }
});

app.post("/api/payment", auth, (req, res) => {
  const userId = req.session.userId;
  const biller = String(req.body.biller || "").trim().slice(0, 80);
  if (!["Metro Utilities (fictional)","Northstar Internet (fictional)","Evergreen Insurance (fictional)","City Water Services (fictional)"].includes(biller))
    return res.status(400).json({ error: "Choose a listed fictional biller." });
  let amount;
  try { amount = cents(req.body.amount); } catch (e) { return res.status(400).json({ error: e.message }); }
  const account = getAccounts(userId).find(a => a.kind === "checking");
  try {
    db.transaction(() => {
      const current = db.prepare("SELECT balance_cents FROM accounts WHERE id=?").get(account.id);
      if (current.balance_cents < amount) throw new Error("Insufficient simulated funds.");
      db.prepare("UPDATE accounts SET balance_cents=balance_cents-? WHERE id=?").run(amount, account.id);
      addTx(userId, account.id, "Bill payment", biller, -amount);
    })();
    res.json(snapshot(userId));
  } catch (e) { res.status(400).json({ error: e.message || "Payment failed." }); }
});
app.post("/api/card", auth, (req, res) => {
  const frozen = req.body.frozen ? 1 : 0;
  db.prepare("UPDATE users SET card_frozen=? WHERE id=?").run(frozen, req.session.userId);
  res.json(snapshot(req.session.userId));
});
app.get("/api/export.csv", auth, (req, res) => {
  const rows = db.prepare(`SELECT t.created_at,t.type,t.description,t.amount_cents,t.status,t.reference,a.name
    FROM transactions t JOIN accounts a ON a.id=t.account_id WHERE t.user_id=? ORDER BY t.id DESC`).all(req.session.userId);
  const quote = v => '"' + String(v ?? "").replace(/"/g, '""') + '"';
  const csv = ["Date,Type,Description,Account,Amount USD,Status,Reference", ...rows.map(r =>
    [r.created_at,r.type,r.description,r.name,money(r.amount_cents),r.status,r.reference].map(quote).join(","))].join("\r\n");
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename=aurex-simulator-transactions.csv");
  res.send(csv);
});
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`AUREX simulator running at http://localhost:${PORT}`));
